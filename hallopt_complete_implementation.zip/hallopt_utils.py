import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import json
import pickle
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
import warnings
warnings.filterwarnings('ignore')


class ConfigManager:
    def __init__(self, config_path=None):
        self.config = self._get_default_config()
        if config_path:
            self.load_config(config_path)
    
    def _get_default_config(self):
        return {
            'model': {
                'vocab_size': 10000,
                'teacher_hidden_size': 512,
                'student_hidden_size': 256,
                'num_teacher_layers': 6,
                'num_student_layers': 3,
                'num_heads': 8,
                'intermediate_size': 2048,
                'max_position_embeddings': 512,
                'dropout': 0.1
            },
            'training': {
                'batch_size': 32,
                'num_epochs': 15,
                'learning_rate': 3e-5,
                'warmup_steps': 100,
                'weight_decay': 0.01,
                'gradient_clip': 1.0
            },
            'loss_weights': {
                'lambda_distill': 1.0,
                'lambda_task': 1.0,
                'lambda_hall': 0.5,
                'lambda_feat': 0.3
            },
            'inference': {
                'temperature': 4.0,
                'target_retention': 0.45,
                'hallucination_threshold': 0.5,
                'latency_budget_ms': 50
            },
            'quantization': {
                'enabled': True,
                'bit_width': 8,
                'symmetric': True
            },
            'device': 'cuda' if torch.cuda.is_available() else 'cpu'
        }
    
    def load_config(self, config_path):
        with open(config_path, 'r') as f:
            self.config = json.load(f)
    
    def save_config(self, config_path):
        with open(config_path, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def update(self, updates: Dict):
        for key, value in updates.items():
            if isinstance(value, dict) and key in self.config:
                self.config[key].update(value)
            else:
                self.config[key] = value
    
    def get(self, key: str, default=None):
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k, default)
            else:
                return default
        return value


class CheckpointManager:
    def __init__(self, checkpoint_dir='checkpoints'):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(exist_ok=True)
    
    def save_checkpoint(self, models: Dict, config: Dict, metrics: Dict, epoch: int):
        checkpoint_path = self.checkpoint_dir / f'checkpoint_epoch_{epoch}.pt'
        
        checkpoint = {
            'epoch': epoch,
            'timestamp': datetime.now().isoformat(),
            'config': config,
            'models': {name: model.state_dict() for name, model in models.items()},
            'metrics': metrics
        }
        
        torch.save(checkpoint, checkpoint_path)
        return checkpoint_path
    
    def load_checkpoint(self, checkpoint_path: str, models: Dict = None):
        checkpoint = torch.load(checkpoint_path)
        
        if models:
            for name, model in models.items():
                if name in checkpoint['models']:
                    model.load_state_dict(checkpoint['models'][name])
        
        return checkpoint
    
    def get_best_checkpoint(self, metric='eval_accuracy'):
        checkpoints = list(self.checkpoint_dir.glob('checkpoint_*.pt'))
        
        best_checkpoint = None
        best_value = -float('inf')
        
        for cp_path in checkpoints:
            cp = torch.load(cp_path)
            if metric in cp['metrics']:
                value = cp['metrics'][metric]
                if value > best_value:
                    best_value = value
                    best_checkpoint = cp_path
        
        return best_checkpoint


class MetricsTracker:
    def __init__(self):
        self.metrics = {}
        self.history = {}
    
    def update(self, **kwargs):
        for key, value in kwargs.items():
            self.metrics[key] = value
            
            if key not in self.history:
                self.history[key] = []
            self.history[key].append(value)
    
    def get(self, key=None):
        if key:
            return self.metrics.get(key)
        return self.metrics
    
    def get_history(self, key=None):
        if key:
            return self.history.get(key, [])
        return self.history
    
    def reset(self):
        self.metrics = {}
    
    def save(self, path):
        with open(path, 'w') as f:
            json.dump(self.history, f, indent=2, default=str)
    
    def load(self, path):
        with open(path, 'r') as f:
            self.history = json.load(f)


class DataProcessor:
    @staticmethod
    def normalize_text(text: str) -> str:
        text = text.lower()
        text = ' '.join(text.split())
        return text
    
    @staticmethod
    def tokenize_text(text: str, max_length: int = 512) -> List[int]:
        tokens = text.split()
        return tokens[:max_length]
    
    @staticmethod
    def pad_sequence(tokens: List[int], max_length: int, pad_token: int = 0) -> torch.Tensor:
        if len(tokens) < max_length:
            tokens = tokens + [pad_token] * (max_length - len(tokens))
        else:
            tokens = tokens[:max_length]
        return torch.tensor(tokens, dtype=torch.long)
    
    @staticmethod
    def create_attention_mask(seq_len: int, pad_len: int) -> torch.Tensor:
        mask = torch.ones(seq_len)
        mask[pad_len:] = 0
        return mask


class Logger:
    def __init__(self, log_path='training.log'):
        self.log_path = log_path
        self.logs = []
    
    def log(self, message: str, level: str = 'INFO'):
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_message = f'[{timestamp}] [{level}] {message}'
        self.logs.append(log_message)
        print(log_message)
    
    def save_logs(self):
        with open(self.log_path, 'w') as f:
            f.write('\n'.join(self.logs))
    
    def info(self, message: str):
        self.log(message, 'INFO')
    
    def warning(self, message: str):
        self.log(message, 'WARNING')
    
    def error(self, message: str):
        self.log(message, 'ERROR')


class PerformanceMonitor:
    def __init__(self):
        self.measurements = {}
    
    def start_timer(self, name: str):
        import time
        if name not in self.measurements:
            self.measurements[name] = {'times': [], 'start': None}
        self.measurements[name]['start'] = time.time()
    
    def stop_timer(self, name: str):
        import time
        if name in self.measurements and self.measurements[name]['start']:
            elapsed = time.time() - self.measurements[name]['start']
            self.measurements[name]['times'].append(elapsed)
            return elapsed
        return None
    
    def get_stats(self, name: str) -> Dict:
        if name not in self.measurements or not self.measurements[name]['times']:
            return {}
        
        times = np.array(self.measurements[name]['times'])
        return {
            'mean': times.mean(),
            'std': times.std(),
            'min': times.min(),
            'max': times.max(),
            'count': len(times)
        }
    
    def print_stats(self):
        for name in self.measurements:
            stats = self.get_stats(name)
            if stats:
                print(f'{name}: mean={stats["mean"]:.4f}s, std={stats["std"]:.4f}s')


class WeightInitializer:
    @staticmethod
    def xavier_uniform(module: nn.Module):
        for param in module.parameters():
            if param.dim() > 1:
                nn.init.xavier_uniform_(param)
    
    @staticmethod
    def kaiming_normal(module: nn.Module):
        for param in module.parameters():
            if param.dim() > 1:
                nn.init.kaiming_normal_(param, mode='fan_out', nonlinearity='relu')
    
    @staticmethod
    def normal_(module: nn.Module, mean=0.0, std=0.02):
        for param in module.parameters():
            if param.dim() > 1:
                nn.init.normal_(param, mean=mean, std=std)


class GradientAnalyzer:
    @staticmethod
    def check_gradients(model: nn.Module) -> Dict:
        stats = {
            'total_norm': 0.0,
            'max_norm': 0.0,
            'has_nan': False,
            'has_inf': False,
            'layers': {}
        }
        
        for name, param in model.named_parameters():
            if param.grad is not None:
                grad_norm = param.grad.data.norm(2)
                stats['total_norm'] += grad_norm.item() ** 2
                stats['max_norm'] = max(stats['max_norm'], grad_norm.item())
                
                if torch.isnan(param.grad).any():
                    stats['has_nan'] = True
                if torch.isinf(param.grad).any():
                    stats['has_inf'] = True
                
                stats['layers'][name] = grad_norm.item()
        
        stats['total_norm'] = stats['total_norm'] ** 0.5
        return stats


class DataAugmentation:
    @staticmethod
    def random_masking(tokens: torch.Tensor, mask_prob: float = 0.15) -> Tuple[torch.Tensor, torch.Tensor]:
        mask = torch.bernoulli(torch.full(tokens.shape, mask_prob))
        masked_tokens = tokens.clone()
        masked_tokens[mask.bool()] = 103
        return masked_tokens, mask
    
    @staticmethod
    def random_insertion(tokens: torch.Tensor, insert_prob: float = 0.1) -> torch.Tensor:
        mask = torch.bernoulli(torch.full(tokens.shape, insert_prob))
        return tokens * (1 - mask).long()
    
    @staticmethod
    def random_swap(tokens: torch.Tensor, swap_prob: float = 0.05) -> torch.Tensor:
        n = tokens.shape[-1]
        indices = torch.arange(n)
        
        mask = torch.bernoulli(torch.full((n,), swap_prob))
        swap_idx = torch.where(mask)[0]
        
        for i in swap_idx:
            j = torch.randint(0, n, (1,)).item()
            tokens[..., i], tokens[..., j] = tokens[..., j].clone(), tokens[..., i].clone()
        
        return tokens


class ModelAnalyzer:
    @staticmethod
    def count_parameters(model: nn.Module) -> Dict:
        total_params = 0
        trainable_params = 0
        
        for param in model.parameters():
            total_params += param.numel()
            if param.requires_grad:
                trainable_params += param.numel()
        
        return {
            'total': total_params,
            'trainable': trainable_params,
            'non_trainable': total_params - trainable_params
        }
    
    @staticmethod
    def get_model_size(model: nn.Module) -> Dict:
        param_size = 0
        buffer_size = 0
        
        for param in model.parameters():
            param_size += param.nelement() * param.element_size()
        
        for buffer in model.buffers():
            buffer_size += buffer.nelement() * buffer.element_size()
        
        total_size = (param_size + buffer_size) / 1024 / 1024
        
        return {
            'param_size_mb': param_size / 1024 / 1024,
            'buffer_size_mb': buffer_size / 1024 / 1024,
            'total_size_mb': total_size
        }
    
    @staticmethod
    def estimate_flops(batch_size: int, seq_len: int, hidden_size: int, num_layers: int) -> float:
        attention_flops = num_layers * 2 * seq_len * seq_len * hidden_size
        ffn_flops = num_layers * 2 * seq_len * hidden_size * (hidden_size * 4)
        embedding_flops = seq_len * hidden_size
        
        total_flops = (attention_flops + ffn_flops + embedding_flops) * batch_size
        return total_flops


class ValidationHandler:
    @staticmethod
    def validate_config(config: Dict) -> bool:
        required_keys = ['model', 'training', 'inference']
        for key in required_keys:
            if key not in config:
                return False
        
        if config['model']['hidden_size'] % config['model']['num_heads'] != 0:
            return False
        
        return True
    
    @staticmethod
    def validate_inputs(input_ids: torch.Tensor, max_length: int) -> bool:
        if not isinstance(input_ids, torch.Tensor):
            return False
        
        if input_ids.shape[-1] > max_length:
            return False
        
        if input_ids.dtype not in [torch.long, torch.int32, torch.int64]:
            return False
        
        return True


class ExportHandler:
    @staticmethod
    def export_to_onnx(model: nn.Module, dummy_input: torch.Tensor, output_path: str):
        try:
            torch.onnx.export(
                model,
                dummy_input,
                output_path,
                export_params=True,
                opset_version=12,
                do_constant_folding=True,
                input_names=['input_ids'],
                output_names=['output']
            )
            return True
        except Exception as e:
            print(f'ONNX export failed: {e}')
            return False
    
    @staticmethod
    def export_to_torchscript(model: nn.Module, output_path: str):
        try:
            scripted_model = torch.jit.script(model)
            scripted_model.save(output_path)
            return True
        except Exception as e:
            print(f'TorchScript export failed: {e}')
            return False


if __name__ == '__main__':
    config_manager = ConfigManager()
    print('Config:', config_manager.config)
    
    checkpoint_manager = CheckpointManager()
    metrics_tracker = MetricsTracker()
    logger = Logger()
    monitor = PerformanceMonitor()
    
    logger.info('Utilities module loaded successfully')
