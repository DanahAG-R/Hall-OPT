import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class HallucinationAwareAttentionMechanism(nn.Module):
    def __init__(self, hidden_size, num_heads, dropout=0.1):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        assert hidden_size % num_heads == 0
        
        self.query = nn.Linear(hidden_size, hidden_size)
        self.key = nn.Linear(hidden_size, hidden_size)
        self.value = nn.Linear(hidden_size, hidden_size)
        self.out_proj = nn.Linear(hidden_size, hidden_size)
        
        self.alpha = nn.Parameter(torch.ones(1))
        self.beta = nn.Parameter(torch.ones(1))
        self.gamma = nn.Parameter(torch.ones(1))
        self.tau_hall = nn.Parameter(torch.tensor(0.5))
        
        self.dropout = nn.Dropout(dropout)
        self.scale = math.sqrt(self.head_dim)
    
    def forward(self, hidden_states):
        batch_size, seq_len, _ = hidden_states.shape
        
        Q = self.query(hidden_states).view(batch_size, seq_len, self.num_heads, self.head_dim)
        K = self.key(hidden_states).view(batch_size, seq_len, self.num_heads, self.head_dim)
        V = self.value(hidden_states).view(batch_size, seq_len, self.num_heads, self.head_dim)
        
        Q = Q.transpose(1, 2)
        K = K.transpose(1, 2)
        V = V.transpose(1, 2)
        
        scores = torch.matmul(Q, K.transpose(-2, -1)) / self.scale
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        
        context = torch.matmul(attn_weights, V)
        context = context.transpose(1, 2).contiguous()
        context = context.view(batch_size, seq_len, self.hidden_size)
        
        output = self.out_proj(context)
        
        attn_entropy = self._compute_entropy(attn_weights)
        output_probs = F.softmax(output, dim=-1)
        output_uncertainty = self._compute_uncertainty(output_probs)
        context_consistency = self._compute_consistency(attn_weights)
        
        hallucination_scores = (
            self.alpha * attn_entropy + 
            self.beta * output_uncertainty + 
            self.gamma * context_consistency
        )
        
        return output, hallucination_scores, attn_weights
    
    def _compute_entropy(self, attn_weights):
        entropy = -(attn_weights * torch.log(attn_weights + 1e-10)).sum(dim=-1)
        return entropy.mean(dim=(1, 2))
    
    def _compute_uncertainty(self, probs):
        max_probs = probs.max(dim=-1)[0]
        uncertainty = 1.0 - max_probs
        return uncertainty.mean(dim=-1)
    
    def _compute_consistency(self, attn_weights):
        context_attn = attn_weights.mean(dim=1, keepdim=True)
        consistency = 1.0 - F.cosine_similarity(
            attn_weights.view(-1, attn_weights.shape[-1]),
            context_attn.expand_as(attn_weights).view(-1, attn_weights.shape[-1]),
            dim=-1
        )
        return consistency.mean()


class DynamicTokenPruning(nn.Module):
    def __init__(self, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.omega1 = nn.Parameter(torch.ones(1))
        self.omega2 = nn.Parameter(torch.ones(1))
        self.omega3 = nn.Parameter(torch.ones(1))
    
    def forward(self, hidden_states, attn_weights, hallucination_scores, target_retention=0.45):
        batch_size, seq_len, _ = hidden_states.shape
        
        h_norm = torch.norm(hidden_states, p=2, dim=-1)
        attn_sum = attn_weights.sum(dim=(1, 2))
        
        importance_scores = (
            self.omega1 * h_norm +
            self.omega2 * attn_sum +
            self.omega3 * (1.0 - hallucination_scores.unsqueeze(-1))
        )
        
        importance_scores = importance_scores.view(batch_size, seq_len)
        
        mu = importance_scores.mean(dim=1, keepdim=True)
        sigma = importance_scores.std(dim=1, keepdim=True)
        
        from scipy.stats import norm as scipy_norm
        threshold = (mu + sigma * scipy_norm.ppf(1 - target_retention)).squeeze()
        
        pruning_mask = (importance_scores >= threshold.unsqueeze(1)).float()
        pruned_states = hidden_states * pruning_mask.unsqueeze(-1)
        
        return pruned_states, pruning_mask, importance_scores


class AdaptiveKnowledgeDistillation(nn.Module):
    def __init__(self, hidden_size, num_layers):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.projection_matrices = nn.ModuleList([
            nn.Linear(hidden_size, hidden_size) for _ in range(num_layers)
        ])
    
    def compute_distillation_loss(self, teacher_logits, student_logits, temperature=4.0):
        teacher_probs = F.softmax(teacher_logits / temperature, dim=-1)
        student_log_probs = F.log_softmax(student_logits / temperature, dim=-1)
        kld = F.kl_div(student_log_probs, teacher_probs, reduction='batchmean')
        return kld * (temperature ** 2)
    
    def compute_feature_distillation_loss(self, teacher_features, student_features):
        loss = 0
        for i, (tf, sf) in enumerate(zip(teacher_features, student_features)):
            projected_sf = self.projection_matrices[i](sf)
            loss += F.mse_loss(projected_sf, tf)
        return loss / len(teacher_features)
    
    def compute_hallucination_aware_loss(self, student_logits, teacher_logits, hallucination_scores):
        mse_loss = F.mse_loss(student_logits, teacher_logits, reduction='none')
        weighted_loss = (hallucination_scores.unsqueeze(-1) * mse_loss).mean()
        return weighted_loss


class EdgeOptimizationLayer(nn.Module):
    def __init__(self, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
    
    def quantize_weights(self, weights, bit_width=8):
        scale = torch.max(torch.abs(weights)) / (2 ** (bit_width - 1))
        quantized = torch.clamp(torch.round(weights / scale), 
                               -(2 ** (bit_width - 1)), 
                               2 ** (bit_width - 1) - 1) * scale
        return quantized


class HALLOPTTransformerLayer(nn.Module):
    def __init__(self, hidden_size, num_heads, intermediate_size, dropout=0.1):
        super().__init__()
        self.hidden_size = hidden_size
        
        self.haam = HallucinationAwareAttentionMechanism(hidden_size, num_heads, dropout)
        self.dtp = DynamicTokenPruning(hidden_size)
        
        self.norm1 = nn.LayerNorm(hidden_size)
        self.norm2 = nn.LayerNorm(hidden_size)
        
        self.ffn = nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.GELU(),
            nn.Linear(intermediate_size, hidden_size),
            nn.Dropout(dropout)
        )
    
    def forward(self, hidden_states, target_retention=0.45):
        normed = self.norm1(hidden_states)
        attn_output, hall_scores, attn_weights = self.haam(normed)
        pruned_output, pruning_mask, importance_scores = self.dtp(
            attn_output, attn_weights, hall_scores, target_retention
        )
        hidden_states = hidden_states + pruned_output
        
        normed = self.norm2(hidden_states)
        ffn_output = self.ffn(normed)
        hidden_states = hidden_states + ffn_output
        
        return hidden_states, hall_scores, attn_weights, importance_scores


class HALLOPTTransformer(nn.Module):
    def __init__(self, vocab_size, hidden_size=512, num_layers=6, num_heads=8, 
                 intermediate_size=2048, dropout=0.1, max_position_embeddings=512):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        self.embeddings = nn.Embedding(vocab_size, hidden_size)
        self.position_embeddings = nn.Embedding(max_position_embeddings, hidden_size)
        self.layer_norm = nn.LayerNorm(hidden_size)
        self.dropout = nn.Dropout(dropout)
        
        self.layers = nn.ModuleList([
            HALLOPTTransformerLayer(hidden_size, num_heads, intermediate_size, dropout)
            for _ in range(num_layers)
        ])
        
        self.lm_head = nn.Linear(hidden_size, vocab_size)
        self.akd = AdaptiveKnowledgeDistillation(hidden_size, num_layers)
        self.eol = EdgeOptimizationLayer(hidden_size)
    
    def forward(self, input_ids, target_retention=0.45, return_all_hiddens=False):
        batch_size, seq_len = input_ids.shape
        
        embeddings = self.embeddings(input_ids)
        position_ids = torch.arange(seq_len, device=input_ids.device).unsqueeze(0).expand(batch_size, -1)
        position_embeddings = self.position_embeddings(position_ids)
        
        hidden_states = embeddings + position_embeddings
        hidden_states = self.layer_norm(hidden_states)
        hidden_states = self.dropout(hidden_states)
        
        all_hidden_states = [hidden_states]
        all_attention_weights = []
        all_hallucination_scores = []
        
        for layer in self.layers:
            hidden_states, hall_scores, attn_weights, importance_scores = layer(
                hidden_states, target_retention
            )
            all_hidden_states.append(hidden_states)
            all_attention_weights.append(attn_weights)
            all_hallucination_scores.append(hall_scores)
        
        logits = self.lm_head(hidden_states)
        
        if return_all_hiddens:
            return logits, all_hidden_states, all_attention_weights, all_hallucination_scores
        return logits, all_hallucination_scores[-1]
    
    def get_intermediate_features(self, input_ids, target_retention=0.45):
        batch_size, seq_len = input_ids.shape
        
        embeddings = self.embeddings(input_ids)
        position_ids = torch.arange(seq_len, device=input_ids.device).unsqueeze(0).expand(batch_size, -1)
        position_embeddings = self.position_embeddings(position_ids)
        
        hidden_states = embeddings + position_embeddings
        hidden_states = self.layer_norm(hidden_states)
        hidden_states = self.dropout(hidden_states)
        
        features = [hidden_states]
        
        for layer in self.layers:
            hidden_states, _, _, _ = layer(hidden_states, target_retention)
            features.append(hidden_states)
        
        return features
